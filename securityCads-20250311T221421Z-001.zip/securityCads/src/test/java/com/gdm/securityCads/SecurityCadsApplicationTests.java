package com.gdm.securityCads;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityCadsApplicationTests {

	@Test
	void contextLoads() {
	}

}
