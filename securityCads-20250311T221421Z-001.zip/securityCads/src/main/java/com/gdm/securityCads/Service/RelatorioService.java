package com.gdm.securityCads.Service;

import org.springframework.stereotype.Service;

@Service
public class RelatorioService {

	public void gerarRelatorio() {



	}

	public String nome() {
		return nome();
	}

}
