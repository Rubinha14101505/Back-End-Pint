package com.gdm.securityCads.Service;

public class BiometriaService {

}
